#include<bits/stdc++.h>
using namespace std;
void __()
{
	long long n,p;
	cin>>n>>p;
	while(n>p){
		n-=p;
	}
	if(n==p) cout<<0<<endl; else
	cout<<n<<endl;
}
int main()
{
	__();
	__();
	__();
	__();
	__();
	__();
	__();
	__();
	__();
	__();
}
