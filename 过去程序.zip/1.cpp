#include<bits/stdc++.h>
using namespace std;
void _()
{
	int a,b;
	cin>>a>>b;
	multiset<int> s;
	for(int i=1;i<=a;i++) s.insert(i);
	for(int i=1;i<=b;i++) s.insert(i);
	cout<<s.size()<<endl;
}
int main()
{
	_();
	_();
	_();
	_();
	_();
	_();
	_();
	_();
	_();
	_();
}
